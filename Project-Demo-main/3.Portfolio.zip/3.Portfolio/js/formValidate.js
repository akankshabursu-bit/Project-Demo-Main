
/*
 * Handles the submit event of the contact form
 *
 * param e  A reference to the event object
 * return   True if no validation errors; False if the form has
 *          validation errors
 */
function validate(e) {
	
	hideErrors();

	if (formHasErrors()) {

		e.preventDefault();

		return false;
	}
	return true;
}

/*
 * Handles the reset event for the form.
 *
 * param e  A reference to the event object
 * return   True allows the reset to happen; False prevents
 *          the browser from resetting the form.
 */
function resetForm(e) {

	if (confirm('Clear the form?')) {
		
		hideErrors();
		document.getElementById("name").focus();
		document.getElementById("name").select();
		return true;
	}

	e.preventDefault();

	return false;
}

/*
 * Does all the error checking for the form.
 *
 * return   True if an error was found; False if no errors were found
 */
function formHasErrors() {
	
	let errorFlag = false
	
	// Check the text input is empty or not
	let inputTexts = ["name","phone","email","message"];
	
	for(let i = 0; i< inputTexts.length ; i++)
	{
		let textField = document.getElementById(inputTexts[i]);

		if(!formFieldHasInput(textField))
		{
			document.getElementById(inputTexts[i]+"_error").style.display = "block";
			if (!errorFlag) 
			{
				textField.focus();
				textField.select();
			}
			errorFlag = true;
		}
	}

	// Check the format of phone number 
	let regexCode = new RegExp(/^\d{10}$/);
	let phone = document.getElementById("phone");
	
	if(!regexCode.test(phone.value))
	{
		document.getElementById("phoneformat_error").style.display = "block";
		if (!errorFlag) 
		{
			phone.focus();
			phone.select();
		}
		errorFlag = true;
	}

	//check the format of email address
	let regexAddress = new RegExp(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/);
	let emailAddress = document.getElementById("email")
	
	if(!regexAddress.test(emailAddress.value))
	{
		document.getElementById("emailformat_error").style.display = "block";
		if (!errorFlag) 
		{
			emailAddress.focus();
			emailAddress.select();
		}
		errorFlag = true;
	}

	return errorFlag;
}


/*
 * Hides all of the error elements.
 */
function hideErrors() {
	
	let error = document.getElementsByClassName("error");

	for (let i = 0; i < error.length; i++) {
		error[i].style.display = "none";
	}
}

/*
 * Handles the load event of the document.
 */
function load() {
	
	document.getElementById("contactform").addEventListener("submit", validate);

	document.getElementById("contactform").reset();
	document.getElementById("contactform").addEventListener("reset",resetForm);

}

// Add document load event listener
document.addEventListener("DOMContentLoaded", load);
document.addEventListener("DOMContentLoaded", hideErrors);

/*
 * Determines if a text field element has input
 *
 * param   fieldElement A text field input element object
 * return  True if the field contains input; False if nothing entered
 */
function formFieldHasInput(fieldElement) {

	if (fieldElement.value == null || fieldElement.value.trim() == "") {
		return false;
	}
	return true;
}












