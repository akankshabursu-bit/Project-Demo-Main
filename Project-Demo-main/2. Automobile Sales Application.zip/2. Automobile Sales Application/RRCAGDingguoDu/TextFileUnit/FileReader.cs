﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-11
 * Updated: 2022-7-11
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using System.ComponentModel;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents the functionality that get data from reading files.
    /// </summary>
    public static class FileReader
    {

        /// <summary>
        /// Gets the collection from reading files.
        /// </summary>
        /// <param name="filePath">The path of file which contains data for creeating collections</param>
        /// <returns></returns>
        public static BindingList<KeyValuePair<string, string>> GetCollection(string filePath)
        {
            BindingList<KeyValuePair<string, string>> list = new BindingList<KeyValuePair<string, string>>();

            Stream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            Dictionary<string,string> dictionary = new Dictionary<string, string>();

            StreamReader reader = new StreamReader(stream);

            while (reader.Peek() != -1)
            {
                string stringData = reader.ReadLine();

                string[] stringArray = stringData.Split(',');

                dictionary.Add(stringArray[0], stringArray[1]);

            }

            foreach (KeyValuePair<string, string> pair in dictionary)
            {
                list.Add(pair);
            }

            stream.Close();

            reader.Close(); 

            return list;
               
        }
    }
}
