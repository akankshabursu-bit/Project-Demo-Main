﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-13
 * Updated: 2022-7-13
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using Du.Dingguo.Business;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a CarWashForm class.
    /// </summary>
    public partial class CarWashForm : Form
    {
        private BindingList<KeyValuePair<string, string>> packages;
        private BindingList<KeyValuePair<string, string>> fragrances;

        private BindingSource fragrancesSource;
        private BindingSource packagesSource;
        private BindingSource interiorSource;
        private BindingSource exteriorSource;

        private KeyValuePair<string, string> currentFragrancePrice;
        private KeyValuePair<string, string> currentPackagePrice;

        private CarWashInvoice carWashInvoice;

        /// <summary>
        /// Initializes an instance of CarWashForm.
        /// </summary>
        public CarWashForm()
        {
            InitializeComponent();

            try
            {
                packages = FileReader.GetCollection("./TextFileUnit/packages.txt");
            }
            catch(FileNotFoundException)
            {
                string message = "packages data file not found.";
                string caption = "Data File Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon boxIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(message, caption, buttons, boxIcon, defaultButton);
            }
            catch(FileLoadException)
            {
                string message = "An error occurred while reading the data file.";
                string caption = "Data File Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon boxIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(message, caption, buttons, boxIcon, defaultButton);
            }

            try
            {
                fragrances = FileReader.GetCollection("./TextFileUnit/fragrances.txt");
            }
            catch (FileNotFoundException)
            {
                string message = "fragrances data file not found.";
                string caption = "Data File Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon boxIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(message, caption, buttons, boxIcon, defaultButton);
            }
            catch (FileLoadException)
            {
                string message = "An error occurred while reading the data file";
                string caption = "Data File Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon boxIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(message, caption, buttons, boxIcon, defaultButton);
            }

            BindControls();

            resultCaculation();

            this.cboPackage.SelectedIndexChanged += Cbo_SelectedIndexChangedForInterior;
            this.cboFragrance.SelectedIndexChanged += Cbo_SelectedIndexChangedForInterior;
            this.cboPackage.SelectedIndexChanged += Cbo_SelectedIndexChangedForExterior;
            this.cboPackage.SelectedIndexChanged += CboPrice_SelectedIndexChanged;
            this.cboFragrance.SelectedIndexChanged += CboPrice_SelectedIndexChanged;
            this.mnuFileGenerateInvoice.Click += MnuFileGenerateInvoice_Click;

            mnuFileExit.Click += MsFileExit_Click;
        }

        /// <summary>
        ///  Handles the Click event of generating car wash invoice.
        /// </summary>
        private void MnuFileGenerateInvoice_Click(object sender, EventArgs e)
        {
            CarWashInvoiceForm carWashInvoiceForm = new CarWashInvoiceForm(carWashInvoice);
            carWashInvoiceForm.ShowDialog();

        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of combo box selection. 
        /// </summary>
        private void CboPrice_SelectedIndexChanged(object sender, EventArgs e)
        {
            resultCaculation();
        }

        /// <summary>
        /// Calculate the label output from the combo box input.
        /// </summary>
        private void resultCaculation()
        {
            carWashInvoice = new CarWashInvoice(0.05M, 0.07M);

            currentFragrancePrice = (KeyValuePair<string, string>)this.cboFragrance.SelectedItem;
            currentPackagePrice = (KeyValuePair<string, string>)this.cboPackage.SelectedItem;

            carWashInvoice.PackageCost = decimal.Parse(currentPackagePrice.Value);
            carWashInvoice.FragranceCost = decimal.Parse(currentFragrancePrice.Value);

            decimal subtotal = carWashInvoice.SubTotal;
            decimal PST = carWashInvoice.ProvincialSalesTaxCharged;
            decimal GST = carWashInvoice.GoodsAndServicesTaxCharged;
            decimal total = carWashInvoice.Total;   

            lblSubtotal.Text = String.Format("{0:C}", subtotal);
            lblPST.Text = String.Format("{0:F2}", PST);
            lblGST.Text = String.Format("{0:F2}", GST);
            lblTotal.Text = String.Format("{0:C}", total);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of combo box to invoke the exterior items binding.
        /// </summary>
        private void Cbo_SelectedIndexChangedForExterior(object sender, EventArgs e)
        {
            ExteriorItemsBinding();
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of combo box to invoke the interior items binding.
        /// </summary>
        private void Cbo_SelectedIndexChangedForInterior(object sender, EventArgs e)
        {
            InteriorItemsBinding();
        }

        /// <summary>
        /// Date bind the exterior items based on combo box selection. 
        /// </summary>
        private void ExteriorItemsBinding()
        {
            this.exteriorSource = new BindingSource();
            exteriorSource.DataSource = GetExteriorBinding(this.cboPackage.SelectedIndex);
            this.lstExterior.DataSource = this.exteriorSource;
        }

        /// <summary>
        /// Date binds the interior items based on combo box selection. 
        /// </summary>
        private void InteriorItemsBinding()
        {
            this.interiorSource = new BindingSource();
            this.interiorSource.DataSource = GetInteriorBinding(this.cboPackage.SelectedIndex);
            this.lstInterior.DataSource = this.interiorSource;
        }

        /// <summary>
        ///  Handles the Click event of exit menu item.
        /// </summary>
        private void MsFileExit_Click(object sender, EventArgs e)
        {
            this.Close();    
        }

        /// <summary>
        /// Date binds the packages and fragrances data to the combo box.  
        /// </summary>
        private void BindControls()
        {
            this.packagesSource = new BindingSource();
            this.packagesSource.DataSource = packages;
            this.cboPackage.DataSource = this.packagesSource;
            this.cboPackage.DisplayMember = "Key";
            this.cboPackage.SelectedIndex = 0;

            this.fragrancesSource = new BindingSource();
            this.fragrancesSource.DataSource = fragrances;
            this.cboFragrance.DataSource = this.fragrancesSource;
            this.cboFragrance.DisplayMember = "Key";
            this.cboFragrance.ValueMember = "Key";
            this.cboFragrance.SelectedIndex = 4;

            ExteriorItemsBinding();
            InteriorItemsBinding();

        }


        /// <summary>
        /// Return the BindingList collection of fragrance items when fragrances combo box selection made.
        /// </summary>
        /// <param name="index">The fragrance combo box selected index.</param>
        /// <returns></returns>
        private BindingList<string> GetInteriorBinding(int index)
        {
            BindingList<string> list = new BindingList<string>();

            switch (index)
            {
                case 0:
                    list = new BindingList<string> { $"Fragrance-{cboFragrance.SelectedValue}" };
                    break;
                case 1:
                    list = new BindingList<string> {$"Fragrance-{cboFragrance.SelectedValue}", "Shampoo Carpets" };
                    break;
                case 2:
                    list = new BindingList<string> { $"Fragrance-{cboFragrance.SelectedValue}", "Shampoo Carpets", "Shampoo Upholstery" };
                    break;
                case 3:
                    list = new BindingList<string> { $"Fragrance-{cboFragrance.SelectedValue}", "Shampoo Carpets", "Shampoo Upholstery", "Interior Protection Coat" };
                    break;    
            }
            return list;
        }

        /// <summary>
        /// Return the BindingList collection of package items when packages combo box selection made.
        /// </summary>
        /// <param name="index">The package combo box selected index.</param>
        /// <returns></returns>
        private BindingList<string> GetExteriorBinding(int index)
        {
            BindingList<string> list = new BindingList<string>();

            switch (index)
            {
                case 0:
                    list = new BindingList<string> { "Hand Wash" };
                    break;
                case 1:
                    list = new BindingList<string> { "Hand Wash", "Hand Wax" };
                    break;
                case 2:
                    list = new BindingList<string> { "Hand Wash", "Hand Wax", "Wheel Polish" };
                    break;
                case 3:
                    list = new BindingList<string> { "Hand Wash", "Hand Wax", "Wheel Polish", "Detail Engine Compartment" };
                    break;
            }
            return list;
        }

        
    }
}
