﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-13
 * Updated: 2022-7-13
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Du.Dingguo.Business;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a CarWashInvoiceForm class.
    /// </summary>
    public partial class CarWashInvoiceForm : InvoiceForm
    {
        public CarWashInvoiceForm(CarWashInvoice carWashInvoice)
        {
            InitializeComponent();

            lblInvoiceTitle.Text = "Car Wash Invoice";

            lblDate.Text = string.Format("{0:MM/dd/yyyy}", DateTime.Now);

            lblpackagePrice.Text = string.Format("{0:C}",carWashInvoice.PackageCost);

            lblFragrancePrice.Text = carWashInvoice.FragranceCost.ToString();

            lblSubtotal.Text = string.Format("{0:C}", carWashInvoice.SubTotal);

            decimal taxes = carWashInvoice.ProvincialSalesTaxCharged + carWashInvoice.GoodsAndServicesTaxCharged;

            lblTaxes.Text = String.Format("{0:F2}",taxes);
            
            lblTotal.Text = string.Format("{0:C}", carWashInvoice.Total);
        }
    }
}
