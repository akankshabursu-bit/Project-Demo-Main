﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;


namespace DAL
{
    public class SQLHelper
    {
        public static string connString = ConfigurationManager.ConnectionStrings["connString"].ToString();
        //private static string connString = "Data Source=.;Initial Catalog=StudentManager;Integrated Security=True";

        #region 执行格式化SQL语句

        /// <summary>
        /// insert,delete,update
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static int Update(string sql)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sql,conn);
            int result = 0;
            try 
            {
                conn.Open();
                result = cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                //WriteLog("执行public static int Update(string sql)发生异常" + ex.Message);
                throw new Exception();
            }
            finally
            {
                conn.Close();
            }

            return result;

        }

        /// <summary>
        /// 单一结果查询
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static object GetSingleResult(string sql)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sql, conn);
            object result = null;
            try
            {
                conn.Open();
                result = cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //WriteLog("执行public static int Update(string sql)发生异常" + ex.Message);
                throw new Exception();
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// 结果集查询
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static SqlDataReader GetReader(string sql)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader result = null;
            try
            {
                conn.Open();
                result = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                //WriteLog("执行public static int Update(string sql)发生异常" + ex.Message);
                throw new Exception();
            }
           
            return result;
        }



        #endregion

        #region 执行带参数SQL语句和存储过程
        /// <summary>
        ///  执行带参数的增，删，改-SQL语句或者存储过程
        /// </summary>
        /// <param name="sqlOrProcedureName">SQL语句或者存储过程</param>
        /// <param name="parameters">参数</param>
        /// <param name="isProcedure">是否为存储过程</param>
        /// <returns>成功返回1，失败返回0</returns>
        public static int Update(string sqlOrProcedureName, SqlParameter[] parameters, bool isProcedure)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sqlOrProcedureName, conn);
            if(isProcedure)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }
            int result = 0;
            try
            {
                conn.Open();
                cmd.Parameters.AddRange(parameters);
                result = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
            
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        /// <summary>
        ///  执行带参数的单一结果查询-SQL语句或者存储过程
        /// </summary>
        /// <param name="sqlOrProcedureName">SQL语句或者存储过程</param>
        /// <param name="parameters">参数</param>
        /// <param name="isProcedure">是否为存储过程</param>
        /// <returns>单一结果对象</returns>
        public static object GetSingleResult(string sqlOrProcedureName, SqlParameter[] parameters, bool isProcedure)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sqlOrProcedureName, conn);
            if(isProcedure)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }

            object result = null;
            try
            {
                conn.Open();
                cmd.Parameters.AddRange(parameters);
                result = cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
           
                throw new Exception();
            }
            finally
            {
                conn.Close();
            }
            return result;
        }

        /// <summary>
        ///  执行带参数的结果集查询-SQL语句或者存储过程
        /// </summary>
        /// <param name="sqlOrProcedureName">SQL语句或者存储过程</param>
        /// <param name="parameters">参数</param>
        /// <param name="isProcedure">是否为存储过程</param>
        /// <returns>结果集</returns>
        public static SqlDataReader GetReader(string sqlOrProcedureName, SqlParameter[] parameters, bool isProcedure)
        {
            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand(sqlOrProcedureName, conn);
            if(isProcedure)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }
            SqlDataReader result = null;
            try
            {
                conn.Open();
                ConnectionState cs = conn.State;
                cmd.Parameters.AddRange(parameters);
                result = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
            
                throw new Exception();
            }

            return result;
        }

        #endregion

        
    }
}
