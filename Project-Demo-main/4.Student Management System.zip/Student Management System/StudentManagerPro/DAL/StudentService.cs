﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Models;
using DAL;

namespace DAL
{
    public class StudentService
    {
        #region 添加学员
        /// <summary>
        /// 判断身份证号码是否存在
        /// </summary>
        /// <param name="std"></param>
        /// <returns></returns>
        public bool IsIdExisted(string studentIdNo)
        {
            string sql = "select count(*) from Students where StudentIdNo = @studentIdNo";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@studentIdNo",studentIdNo)
            };
           
            bool result = Convert.ToInt32(SQLHelper.GetSingleResult(sql, parameters, false)) > 0 ? true : false;
            return result;
        }

       /// <summary>
       /// 调用存储过程添加学员对象
       /// </summary>
       /// <param name="std">学生对象</param>
       /// <returns>返回添加学生对象的标识列</returns>
         public int AddStudent(Student std)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@StudentName",std.StudentName),
                new SqlParameter("@Gender",std.Gender),
                new SqlParameter("@Birthday",std.Birthday),
                new SqlParameter("@StudentIdNo",std.StudentIdNo),
                new SqlParameter("@PhoneNumber",std.PhoneNumber),
                new SqlParameter("@StudentAddress",std.StudentAddress),
                new SqlParameter("@ClassId",std.ClassId),
            };

            Object result = SQLHelper.GetSingleResult("usp_AddStudent", parameters, true);
            int StudentId = Convert.ToInt32(result);
            return StudentId;
        }
        #endregion

        #region 查询学员

        /// <summary>
        /// 根据班级查询所有学员信息
        /// </summary>
        /// <param name="ClassName"></param>
        /// <returns></returns>
        public List<StudentExt> GetStudentsByClass(string ClassName)
        {
            string sql = "select StudentId,StudentName,Gender,Birthday,StudentIdNo,PhoneNumber,StudentAddress,ClassName,Students.ClassId from Students";
            sql += " inner join StudentClass on Students.ClassId = StudentClass.ClassId";
            sql += " where ClassName = @ClassName";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ClassName", ClassName)
            };

            List<StudentExt> students = new List<StudentExt>();

           
            SqlDataReader sdr= SQLHelper.GetReader(sql,parameters, false);
            while (sdr.Read())
            {
                students.Add(new StudentExt()
                {
                    StudentId = Convert.ToInt32(sdr["StudentId"]),
                    StudentName = sdr["StudentName"].ToString(),
                    Gender = sdr["Gender"].ToString(),
                    Birthday = Convert.ToDateTime(sdr["Birthday"]),
                    ClassName = sdr["ClassName"].ToString(),
                    StudentAddress = sdr["StudentAddress"].ToString()

                });
            }
            sdr.Close();

            return students;

        }

        /// <summary>
        /// 根据学号查询学员详细信息
        /// </summary>
        /// <param name="studentId"></param>
        /// <returns></returns>
        public StudentExt GetStudentByID(string studentId) 
        {
            string sql = "select StudentId,StudentName,Gender,Birthday,StudentIdNo,PhoneNumber,StudentAddress,ClassName,Students.ClassId from Students";
            sql += " inner join StudentClass on Students.ClassId = StudentClass.ClassId";
            sql += " where StudentId = @StudentId";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@StudentId", studentId)
            };
            StudentExt sde = null;
            SqlDataReader sdr = SQLHelper.GetReader(sql,parameters, false); 

            if(sdr.Read())
            {
                sde = new StudentExt()
                {
                    StudentId = Convert.ToInt32(sdr["StudentId"]),
                    StudentName = sdr["StudentName"].ToString(),
                    Gender = sdr["Gender"].ToString(),
                    Birthday = Convert.ToDateTime(sdr["Birthday"]),
                    ClassName = sdr["ClassName"].ToString(),
                    StudentAddress = sdr["StudentAddress"].ToString(),
                    PhoneNumber = sdr["PhoneNumber"].ToString(),
                    StudentIdNo = sdr["StudentIdNo"].ToString(),
                    ClassId = Convert.ToInt32(sdr["ClassId"])
                };
            }
            sdr.Close();
            return sde;

        }

        #endregion

        #region 修改学员
        
        /// <summary>
        /// 修改学员信息时判断身份证号和其他学员是否相同
        /// </summary>
        /// <param name="studentIdNo">身份证号</param>
        /// <param name="studentId">学号</param>
        /// <returns></returns>
        public bool IsIdExisted(string studentIdNo,string studentId)
        {
            string sql = "select count(*) from Students where StudentIdNo = @studentIdNo and StudentId <>@studentId";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@studentIdNo",studentIdNo),
                new SqlParameter("@studentId",studentId)
            };

            bool result = Convert.ToInt32(SQLHelper.GetSingleResult(sql, parameters, false)) > 0 ? true : false;
            return result;
        }

        /// <summary>
        /// 修改学员对象
        /// </summary>
        /// <param name="std"></param>
        /// <returns></returns>        
        public int ModifyStudent(Student std)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@StudentName",std.StudentName),
                new SqlParameter("@Gender",std.Gender),
                new SqlParameter("@Birthday",std.Birthday),
                new SqlParameter("@StudentIdNo",std.StudentIdNo),
                new SqlParameter("@PhoneNumber",std.PhoneNumber),
                new SqlParameter("@StudentAddress",std.StudentAddress),
                new SqlParameter("@ClassId",std.ClassId),
                new SqlParameter("@StudentId",std.StudentId)
            };

            int result = SQLHelper.Update("usp_ModifyStudent", parameters, true);
            
            return result;
        }

        #endregion

        #region 删除学员

        public int DeleteStudent(string studentId)
        {
            string sql = "delete from Students where StudentId = @StudentId";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@studentId",studentId)
            };

            try
            {
                return SQLHelper.Update(sql, parameters, false);
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                {
                    //throw new Exception("被其他实体引用，不能删除");
                    throw new Exception("Fail to delete due to reference");
                }
                       
                else
                {
                   throw new Exception("Datebase Exception" + ex.Message);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DateBase Exception" + ex.Message);
            }
        }
        #endregion
    }
}
