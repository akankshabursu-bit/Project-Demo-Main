﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Models;
using DAL;

namespace DAL
{
    public class StudentClassService
    {
        /// <summary>
        /// 获取所有班级对象集合
        /// </summary>
        /// <returns>班级对象集合</returns>
        public List<StudentClass> GetAllClass()
        {
            string sql = "select ClassId,ClassName from StudentClass";
            SqlDataReader sdr = SQLHelper.GetReader(sql);
            List<StudentClass> list = new List<StudentClass>(); 
            while(sdr.Read())
            {
                list.Add(new StudentClass()
                {
                    ClassId = Convert.ToInt32(sdr["ClassId"]),
                    ClassName = sdr["ClassName"].ToString()
                });
            }
            sdr.Close();
            return list;

        }
    }
}
