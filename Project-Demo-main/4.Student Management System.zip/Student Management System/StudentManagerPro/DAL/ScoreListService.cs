﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Models;


namespace DAL
{
    public class ScoreListService
    {
        /// <summary>
        /// 根据班级查询学生成绩  
        /// </summary>
        /// <param name="ClassName"></param>
        /// <returns></returns>
        public List<StudentExt> GetStudentScore(String ClassName)
        {

            SqlParameter[] parameters = new SqlParameter[]
            {
               new SqlParameter("@ClassName",ClassName)
            };

            SqlDataReader sdr = SQLHelper.GetReader("usp_DisplayScore",parameters,true);

            List<StudentExt> list = new List<StudentExt>();

            while(sdr.Read()) 
            {
                list.Add(new StudentExt()
                {
                    StudentId = Convert.ToInt32(sdr["StudentId"]),
                    StudentName = sdr["StudentName"].ToString(),
                    Gender = sdr["Gender"].ToString(),
                    ClassName= sdr["ClassName"].ToString(),
                    CSharp = sdr["CSharp"].ToString(),
                    SQLServerDB = sdr["SQLServerDB"].ToString()

                });
            }
            sdr.Close();    
            return list;

           ; 
        }
    }
}
