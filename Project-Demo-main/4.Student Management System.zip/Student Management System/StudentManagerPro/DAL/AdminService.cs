﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Models;

namespace DAL
{
    public class AdminService
    {
        /// <summary>
        ///  获取当前登录名
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public SysAdmin UserLogin(SysAdmin admin)
        {
            string sql = "select AdminName from Admins where LoginId = @LoginId and LoginPwd = @LoginPwd";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@LoginId",admin.LoginId),
                new SqlParameter("@LoginPwd",admin.LoginPwd)
            };

            try
            {
                SqlDataReader sdr = SQLHelper.GetReader(sql, parameters, false);
                if(sdr.Read())
                {
                    admin.AdminName = sdr["AdminName"].ToString(); 
                }
                else
                {
                    admin = null;
                }   
                sdr.Close();
            }
            catch (Exception ex) 
            {
                throw new Exception(ex.Message);
            }
                        
            return admin;


        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        public int PwdChange(SysAdmin admin) 
        {
            string sql = "update Admins set LoginPwd = @LoginPwd where LoginId = @LoginId";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@LoginPwd",admin.LoginPwd),
                new SqlParameter("@LoginId",admin.LoginId)
            };

            return SQLHelper.Update(sql,parameters,false);
        
        }

    }
}
