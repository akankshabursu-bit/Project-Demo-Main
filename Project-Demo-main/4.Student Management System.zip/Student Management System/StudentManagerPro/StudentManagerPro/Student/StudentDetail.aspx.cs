﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Models;
using DAL;


namespace StudentManagerPro.Students
{
    public partial class StudentDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string StudentId = Request.QueryString["StudentId"];
                StudentExt sde = new StudentService().GetStudentByID(StudentId);

                if(sde == null) 
                { 
                    Response.Redirect("~/ErrPage.apsx");
                }
                else 
                {
                    ltaStudentId.Text = sde.StudentId.ToString();
                    ltaStudentName.Text = sde.StudentName.ToString();
                    ltaGender.Text = sde.Gender.ToString();
                    ltaBirthday.Text = sde.Birthday.ToString("yyyy-MM-dd");
                    ltaClass.Text = sde.ClassId.ToString();
                    ltaStudentIdNo.Text = sde.StudentIdNo.ToString();
                    ltaPhoneNumber.Text = sde.PhoneNumber.ToString();
                    ltaAddress.Text = sde.StudentAddress.ToString();
                    stuImg.ImageUrl = "~/Images/Student/" + StudentId + ".jpg";
                }
            }
        }
    }
}