﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Models;
using DAL;


namespace StudentManagerPro.Students
{
    public partial class EditStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                //绑定班级下拉框
                ddlClass.DataSource = new StudentClassService().GetAllClass();
                ddlClass.DataTextField = "ClassName";
                ddlClass.DataValueField = "ClassId";
                ddlClass.DataBind();


                //根据学员ID查询学生信息
                string studentId = Request.QueryString["StudentId"];

                if(studentId == null )
                {
                    Response.Redirect("~/ErrPage.html");
                }
                else
                {
                   StudentExt sde = new StudentService().GetStudentByID(studentId);
                    if(sde == null )
                    {
                        Response.Redirect("~/ErrPage.html");
                    }
                    else
                    {
                        ltaStudentId.Text = sde.StudentId.ToString();
                        txtStuName.Text = sde.StudentName.ToString();
                        ddlGender.Text = sde.Gender.ToString();
                        txtStuBirthday.Text = sde.Birthday.ToString("yyyy-MM-dd");
                        ddlClass.SelectedValue = sde.ClassId.ToString();
                        txtStuIdNo.Text = sde.StudentIdNo.ToString(); 
                        txtPhoneNumber.Text = sde.PhoneNumber.ToString();
                        txtStuAddress.Text= sde.StudentAddress.ToString();
                    }
                }
            }
            
        }

        protected void btnEditStudent_Click(object sender, EventArgs e)
        {
            StudentService ss = new StudentService();

            if(ss.IsIdExisted(txtStuIdNo.Text,ltaStudentId.Text))
            {
                ltaMsg.Text = "<script>alert('The student ID number must be unqiue')</script>";
               
            }
            else 
            { 
                Student stu = new Student()
                {
                    StudentId = Convert.ToInt32(ltaStudentId.Text.Trim()),
                    StudentName = txtStuName.Text.Trim(),
                    Gender = ddlGender.Text.Trim(),
                    Birthday = Convert.ToDateTime(txtStuBirthday.Text.Trim()),
                    StudentIdNo = txtStuIdNo.Text.Trim(),
                    StudentAddress= txtStuAddress.Text.Trim(),
                    PhoneNumber= txtPhoneNumber.Text.Trim(),
                    ClassId = Convert.ToInt32(ddlClass.SelectedValue)
                };

               
                    int result = ss.ModifyStudent(stu);

                    if (result > 0) 
                    {
                        //Response.Redirect("~/Student/UpLoadImage.aspx?StudentId="+ ltaStudentId.Text+"&IsModify=1");
                        Response.Redirect("~/Student/StudentManage.aspx");
                }

                
            }

            

            

            
            
        }
    }
}