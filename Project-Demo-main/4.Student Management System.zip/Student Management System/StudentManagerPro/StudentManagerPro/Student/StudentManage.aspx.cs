﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using DAL;

namespace StudentManagerPro.Students
{
    public partial class StudentManage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            //显示学员信息
            if(!IsPostBack)
            {
                ddlClass.DataSource = new StudentClassService().GetAllClass();
                ddlClass.DataTextField = "ClassName";
                ddlClass.DataValueField = "ClassId";
                ddlClass.DataBind();
            }
            ltaMsg.Text = ""; 
        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
            rpt.DataSource = new StudentService().GetStudentsByClass(ddlClass.SelectedItem.Text);
            rpt.DataBind();
        }

        protected void btnDel_Click(object sender, EventArgs e)
        {
            string StudentId = ((LinkButton)sender).CommandArgument;

            try
            {
                int result = new StudentService().DeleteStudent(StudentId);
                //同步从服务器删除
                if(result == 1)
                {
                    File.Delete(Server.MapPath("~/Images/Student/"+StudentId+".jpg"));
                }
                //刷新界面
                btnQuery_Click(null, null);
            }
            catch(Exception ex)
            {
                ltaMsg.Text = "<script>alert('"+ex.Message+"')</script>";
            }
        }
    }
}