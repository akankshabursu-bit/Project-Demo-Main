﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using Models;


namespace StudentManagerPro.Students
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) 
            { 
                List<StudentClass> list = new StudentClassService().GetAllClass();
                ddlClass.DataSource= list;
                ddlClass.DataTextField = "ClassName";
                ddlClass.DataValueField = "ClassId";
                ddlClass.DataBind();
            }
            ltaMsg.Text = "";
        }

        protected void btnAddStudent_Click(object sender, EventArgs e)
        {

            //封装输入对象
            Student st = new Student()
            {
                StudentName = txtStuName.Text.Trim(),
                Gender = ddlGender.Text.Trim(),
                Birthday = Convert.ToDateTime(txtStuBirthday.Text.Trim()),
                StudentIdNo = txtStuIdNo.Text.Trim(),
                PhoneNumber = txtPhoneNumber.Text.Trim(),
                StudentAddress = txtStuAddress.Text.Trim(),
                ClassId = Convert.ToInt32(ddlClass.SelectedValue)
            };

            //检查身份证号是否存在
            if (new StudentService().IsIdExisted(txtStuIdNo.Text))
            {
                ltaMsg.Text = "<script>alert('The ID number already existed')</script>";
                txtStuIdNo.Text = "";
                return;
            }

            //检查验证码是否正确
            if(txtValidateCode.Text != Session["CheckCode"].ToString())
            {
                ltaMsg.Text = "<script>alert('Incorrect verification code')</script>";
                txtValidateCode.Text = "";
                return;
            }

            //调用通用数据访问类，跳转至图片上传页面
            
            try
            {
                int newStudentId = new StudentService().AddStudent(st);
                if (newStudentId > 0) 
                {
                    Response.Redirect("~/Student/UpLoadImage.aspx?StudentId="+newStudentId, false);
                }
                
            }
            catch (Exception ex) 
            { 
                ltaMsg.Text = "<script>alert("+ex.Message+")</script>";
            }


        }
    }
}