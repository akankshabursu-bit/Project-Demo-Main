﻿using DAL;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace StudentManagerPro
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ibtnLogin_Click(object sender, ImageClickEventArgs e)
        {
            //封装登录信息
            SysAdmin admin = new SysAdmin()
            {
                LoginId = Convert.ToInt32(txtUserId.Text),
                LoginPwd = txtPwd.Text
            };

            //调用数据访问类查询用户信息
            try
            {
                SysAdmin checkResult = new AdminService().UserLogin(admin);
                if (checkResult != null)
                {
                    Session["CurrentUser"] = checkResult;
                    Response.Redirect("~/Default.aspx",false);
                }
                else
                {
                    ltaInfo.Text = "<script>alert('Incorrect UserID or Password！')</script>";
                }
            }
            catch(Exception ex) 
            {
                ltaInfo.Text = "<script>alert("+ex.Message+")</script>";

            }
            
        }
    }
}