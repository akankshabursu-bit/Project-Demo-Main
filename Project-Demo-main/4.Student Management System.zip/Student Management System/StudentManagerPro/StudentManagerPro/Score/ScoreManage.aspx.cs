﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Models;
using DAL;


namespace StudentManagerPro.Score
{
    public partial class ScoreManage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack) 
            {
                ddlClass.DataSource = new StudentClassService().GetAllClass();
                ddlClass.DataTextField = "ClassName";
                ddlClass.DataValueField = "ClassId";
                ddlClass.DataBind();
            }
        }

        /// <summary>
        /// 按照班级查询学员成绩
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            gvScoreList.DataSource= new ScoreListService().GetStudentScore(ddlClass.SelectedItem.Text.Trim());
            gvScoreList.DataBind();
        }

        /// <summary>
        /// 鼠标进入和异常事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvScoreList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if(e.Row.RowType== DataControlRowType.DataRow) 
            {
                e.Row.Attributes.Add("onmouseover","currentcolor=this.style.backgroundColor;this.style.backgroundColor='#6699ff'");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=currentcolor");
            }
        }
    }
}