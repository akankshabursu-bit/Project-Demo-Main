﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Models;
using DAL;


namespace StudentManagerPro
{
    public partial class ChangePwd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Session["CurrentUser"] == null)
                {
                    Response.Redirect("~/AdminLogin.aspx");
                }
            }
        }

        protected void btnChangePwd_Click(object sender, EventArgs e)
        {
            SysAdmin sa = (SysAdmin)Session["CurrentUser"];

            if(sa.LoginPwd != txtOldPwd.Text.Trim()) 
            {
                ltaMsg.Text = "<script>alert('Original password incorrect')</script>";
            }
            else
            {
                sa.LoginPwd = txtNewPwd.Text.Trim();
                int result = new AdminService().PwdChange(sa);

                ltaMsg.Text = result > 0 ? "<script>alert('Scuccess!');location='../Default.aspx'</script>" : "<script>alert('Fail!')</script>";
            }
        }
    }
}