﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class StudentClass
    {
        public int ClassId { get; set; }
        public string ClassName { get; set; }
    }
}